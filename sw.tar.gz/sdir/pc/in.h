/* A dummy in.h for pc/ systems.  */
